<?php
session_start();
require_once __DIR__ . '/config/config.php';

$conexion = Conexion::conectar();

// Consultar empleados con área
$empleados = $conexion->query("
    SELECT e.*, a.nombre AS area 
    FROM empleado e 
    INNER JOIN areas a ON e.area_id = a.id
");

// Consultar roles por empleado
$rolesPorEmpleado = [];
$rolesQuery = $conexion->query("
    SELECT er.empleado_id, r.nombre 
    FROM empleado_rol er 
    INNER JOIN roles r ON er.rol_id = r.id
");
while ($r = $rolesQuery->fetch_assoc()) {
    $rolesPorEmpleado[$r['empleado_id']][] = $r['nombre'];
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Lista de Empleados</title>
    <link rel="stylesheet" href="<?= ASSETS_PATH ?>style.css">
</head>
<body>
    <h2>Lista de empleados</h2>

    <?php if (isset($_SESSION['mensaje'])): ?>
        <div style="padding: 12px; background-color: <?= $_SESSION['tipo_mensaje'] === 'exito' ? '#d4edda' : '#f8d7da' ?>; color: <?= $_SESSION['tipo_mensaje'] === 'exito' ? '#155724' : '#721c24' ?>; border: 1px solid <?= $_SESSION['tipo_mensaje'] === 'exito' ? '#c3e6cb' : '#f5c6cb' ?>; border-radius: 5px; margin-bottom: 20px;">
            <?= $_SESSION['mensaje'] ?>
        </div>
        <?php unset($_SESSION['mensaje'], $_SESSION['tipo_mensaje']); ?>
    <?php endif; ?>

    <div class="btn-left">
        <a href="<?= BASE_URL ?>views/empleados/crear.php" class="btn-crear">➕ Crear </a> 
    </div>

    <table border="1" cellpadding="8" cellspacing="0">
        <thead>
            <tr>
                <th>👤Nombre</th>
                <th>＠ Email</th>
                <th>⚤ Sexo</th>
                <th>💼 Área</th>
                <th>✉ Boletín</th>
                
                <th>⚙︎ Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($emp = $empleados->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($emp['nombre']) ?></td>
                    <td><?= htmlspecialchars($emp['email']) ?></td>
                    <td><?= $emp['sexo'] === 'M' ? 'Masculino' : 'Femenino' ?></td>
                    <td><?= htmlspecialchars($emp['area']) ?></td>
                    <td><?= $emp['boletin'] ? 'Sí' : 'No' ?></td>
                    <td>
                        <a href="<?= BASE_URL ?>views/empleados/editar.php?id=<?= $emp['id'] ?>">📝 Editar</a> | 
                        <a href="<?= CONTROLLER_PATH ?>eliminar.php?id=<?= $emp['id'] ?>" onclick="return confirm('¿Estás seguro de eliminar este empleado?')">🗑️ Eliminar</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</body>
</html>
