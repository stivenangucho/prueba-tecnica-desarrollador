<?php
class Empleado {
    private $db;

    public function __construct($conexion) {
        $this->db = $conexion;
    }

    public function obtenerTodos() {
        return $this->db->query("SELECT * FROM empleados");
    }

    public function insertar($datos) {
        $stmt = $this->db->prepare("INSERT INTO empleados (nombre, correo, sexo, area, descripcion, boletin, rol) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssis", $datos['nombre'], $datos['correo'], $datos['sexo'], $datos['area'], $datos['descripcion'], $datos['boletin'], $datos['rol']);
        return $stmt->execute();
    }

    public function obtenerPorId($id) {
        $stmt = $this->db->prepare("SELECT * FROM empleados WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }

    public function actualizar($id, $datos) {
        $stmt = $this->db->prepare("UPDATE empleados SET nombre=?, correo=?, sexo=?, area=?, descripcion=?, boletin=?, rol=? WHERE id=?");
        $stmt->bind_param("sssssssi", $datos['nombre'], $datos['correo'], $datos['sexo'], $datos['area'], $datos['descripcion'], $datos['boletin'], $datos['rol'], $id);
        return $stmt->execute();
    }

    public function eliminar($id) {
        $stmt = $this->db->prepare("DELETE FROM empleados WHERE id = ?");
        $stmt->bind_param("i", $id);
        return $stmt->execute();
    }
}
?>