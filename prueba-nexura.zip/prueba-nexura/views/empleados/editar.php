<?php
require_once '../../config/config.php';

$conexion = Conexion::conectar();

// Verificar que se haya recibido un ID válido
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("ID de empleado inválido");
}

$id = (int) $_GET['id'];

// Obtener datos del empleado
$consulta = $conexion->prepare("SELECT * FROM empleado WHERE id = ?");
$consulta->bind_param("i", $id);
$consulta->execute();
$resultado = $consulta->get_result();
$empleado = $resultado->fetch_assoc();

if (!$empleado) {
    die("Empleado no encontrado.");
}

// Obtener áreas y roles
$areas = $conexion->query("SELECT * FROM areas");
$roles = $conexion->query("SELECT * FROM roles");

// Obtener roles del empleado
$rolConsulta = $conexion->prepare("SELECT rol_id FROM empleado_rol WHERE empleado_id = ?");
$rolConsulta->bind_param("i", $id);
$rolConsulta->execute();
$rolesEmpleado = $rolConsulta->get_result();

$rolesSeleccionados = [];
while ($r = $rolesEmpleado->fetch_assoc()) {
    $rolesSeleccionados[] = $r['rol_id'];
}
?>


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Empleado</title>
    <link rel="stylesheet" href="<?= ASSETS_PATH ?>style.css">
</head>
<body>
    <h2 style="text-align: center;">Editar Empleado</h2>

    <div style="max-width: 600px; margin: auto;">
    <div style="background-color: #e7f3fe; color:rgb(72, 118, 187); padding: 12px 16px; border: 1px solid #b6d4fe; border-radius: 6px; margin-bottom: 14px; text-align: center;">
    🛈 <em>Los campos marcados con un asterisco (*) son obligatorios.</em>
    </div>

    <form action="<?= CONTROLLER_PATH ?>actualizar.php" method="POST">
        <input type="hidden" name="id" value="<?= $empleado['id'] ?>">

        <label>Nombre completo *</label><br>
        <input type="text" name="nombre" value="<?= htmlspecialchars($empleado['nombre']) ?>" required><br><br>

        <label>Email *</label><br>
        <input type="email" name="email" value="<?= htmlspecialchars($empleado['email']) ?>" required><br><br>

        <label>Sexo *</label><br>
        <input type="radio" name="sexo" value="M" <?= $empleado['sexo'] === 'M' ? 'checked' : '' ?>> Masculino<br>
        <input type="radio" name="sexo" value="F" <?= $empleado['sexo'] === 'F' ? 'checked' : '' ?>> Femenino<br><br>

        <label>Área *</label><br>
        <select name="area" required>
            <option value="">Seleccione...</option>
            <?php while ($a = $areas->fetch_assoc()): ?>
                <option value="<?= $a['id'] ?>" <?= $empleado['area_id'] == $a['id'] ? 'selected' : '' ?>>
                    <?= htmlspecialchars($a['nombre']) ?>
                </option>
            <?php endwhile; ?>
        </select><br><br>

        <label>Descripción *</label><br>
        <textarea name="descripcion" required><?= htmlspecialchars($empleado['descripcion']) ?></textarea><br><br>

        <input type="checkbox" name="boletin" value="1" <?= $empleado['boletin'] ? 'checked' : '' ?>> Deseo recibir boletín<br><br>

        <label>Roles *</label><br>
        <?php while ($r = $roles->fetch_assoc()): ?>
            <input type="checkbox" name="roles[]" value="<?= $r['id'] ?>" 
                <?= in_array($r['id'], $rolesSeleccionados) ? 'checked' : '' ?>>
            <?= htmlspecialchars($r['nombre']) ?><br>
        <?php endwhile; ?>
        <br>

        <input type="submit" value="Actualizar">
        <a href="<?= BASE_URL ?>index.php">Cancelar</a>
    </form>
    </div>
</body>
</html>
