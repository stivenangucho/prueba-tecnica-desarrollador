<?php
require_once('../../config/config.php');

$conexion = Conexion::conectar();

// Obtener áreas
$areas = $conexion->query("SELECT * FROM areas");

// Obtener roles
$roles = $conexion->query("SELECT * FROM roles");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registrar Empleado</title>
    <link rel="stylesheet" href="<?= ASSETS_PATH ?>style.css">
    <script>
    function validarFormulario() {
        const nombre = document.forms["formEmpleado"]["nombre"].value.trim();
        const email = document.forms["formEmpleado"]["email"].value.trim();
        const sexo = document.forms["formEmpleado"]["sexo"].value;
        const area = document.forms["formEmpleado"]["area"].value;
        const descripcion = document.forms["formEmpleado"]["descripcion"].value.trim();
        const roles = document.querySelectorAll('input[name="roles[]"]:checked');

        if (nombre === "" || email === "" || sexo === "" || area === "" || descripcion === "" || roles.length === 0) {
            alert("Todos los campos marcados con * son obligatorios.");
            return false;
        }

        const emailRegex = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;
        if (!emailRegex.test(email)) {
            alert("Ingrese un correo electrónico válido.");
            return false;
        }

        return true;
    }
    </script>
</head>
<body>
    <h2 style="text-align: center;">Crear empleado</h2>
    <div style="max-width: 600px; margin: auto;">
    <div style="background-color: #e7f3fe; color:rgba(44, 105, 197, 1); padding: 12px 16px; border: 1px solid #9dc6ffff; border-radius: 6px; margin-bottom: 14px; text-align: center;">
    🛈 <em>Los campos marcados con un asterisco (*) son obligatorios.</em>
    </div>

    <div style="max-width: 600px; margin: auto;">

    <form name="formEmpleado" action="<?= CONTROLLER_PATH ?>guardar.php" method="POST" onsubmit="return validarFormulario();">
        <label>Nombre completo *</label><br>
        <input type="text" name="nombre" placeholder="Nombre completo del empleado" required><br><br>

        <label>Email *</label><br>
        <input type="email" name="email" placeholder="Correo electrónico" required><br><br>

        <label>Sexo *</label><br>
        <div>
            <input type="radio" name="sexo" value="M" required> Masculino<br>
            <input type="radio" name="sexo" value="F" required> Femenino
        </div><br>

        <label>Área *</label><br>
        <select name="area" required>
            <option value="">Seleccione...</option>
            <?php while($row = $areas->fetch_assoc()): ?>
                <option value="<?= $row['id'] ?>"><?= htmlspecialchars($row['nombre']) ?></option>
            <?php endwhile; ?>
        </select><br><br>

        <label>Descripción *</label><br>
        <textarea name="descripcion" placeholder="Descripción de la experincia del empleado" required></textarea><br><br>

        <input type="checkbox" name="boletin" value="1"> Deseo recibir boletín informativo<br><br>

        <label>Roles *</label><br>
        <?php while($r = $roles->fetch_assoc()): ?>
            <input type="checkbox" name="roles[]" value="<?= $r['id'] ?>"> <?= htmlspecialchars($r['nombre']) ?><br>
        <?php endwhile; ?>
        <br>

        <input type="submit" value="Guardar">
        <a href="<?= BASE_URL ?>index.php">Cancelar</a>
    </form>

    <script>
    function validarFormulario() {
        document.querySelectorAll('.input-error').forEach(el => el.classList.remove('input-error'));

        let valido = true;
        const form = document.forms["formEmpleado"];

        const nombre = form["nombre"];
        const email = form["email"];
        const area = form["area"];
        const descripcion = form["descripcion"];
        const sexo = form.querySelectorAll('input[name="sexo"]');
        const roles = document.querySelectorAll('input[name="roles[]"]:checked');

        if (nombre.value.trim() === "") {
            nombre.classList.add('input-error');
            valido = false;
        }

        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (email.value.trim() === "" || !emailRegex.test(email.value.trim())) {
            email.classList.add('input-error');
            valido = false;
        }

        let sexoSeleccionado = false;
        sexo.forEach(s => {
            if (s.checked) sexoSeleccionado = true;
        });
        if (!sexoSeleccionado) {
            sexo.forEach(s => s.parentElement.classList.add('input-error'));
            valido = false;
        }

        if (area.value === "") {
            area.classList.add('input-error');
            valido = false;
        }

        if (descripcion.value.trim() === "") {
            descripcion.classList.add('input-error');
            valido = false;
        }

        if (roles.length === 0) {
            document.querySelectorAll('input[name="roles[]"]').forEach(el => el.parentElement.classList.add('input-error'));
            valido = false;
        }

        if (!valido) {
            alert("Por favor completa correctamente los campos marcados en rojo.");
        }

        return valido;
    }
    </script>

    </div>
</body>
</html>
