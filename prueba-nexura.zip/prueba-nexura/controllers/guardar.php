<?php
session_start();
require_once('../config/config.php');

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $conexion = Conexion::conectar();

    // Obtener y sanitizar datos
    $nombre = trim($_POST['nombre'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $sexo = $_POST['sexo'] ?? '';
    $area = (int) ($_POST['area'] ?? 0);
    $descripcion = trim($_POST['descripcion'] ?? '');
    $boletin = isset($_POST['boletin']) ? 1 : 0;
    $roles = $_POST['roles'] ?? [];

    // Validación
    if ($nombre === "" || $email === "" || $sexo === "" || $area === 0 || $descripcion === "" || empty($roles)) {
        die("Todos los campos obligatorios deben ser completados.");
    }

    // Insertar empleado
    $stmt = $conexion->prepare("INSERT INTO empleado (nombre, email, sexo, area_id, boletin, descripcion) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssiss", $nombre, $email, $sexo, $area, $boletin, $descripcion);

    if (!$stmt->execute()) {
        die("Error al insertar empleado: " . $stmt->error);
    }

    $empleado_id = $stmt->insert_id;
    $stmt->close();

    // Insertar roles
    $stmt_rol = $conexion->prepare("INSERT INTO empleado_rol (empleado_id, rol_id) VALUES (?, ?)");
    foreach ($roles as $rol_id) {
        $rol_id = (int) $rol_id;
        $stmt_rol->bind_param("ii", $empleado_id, $rol_id);
        $stmt_rol->execute();
    }
    $stmt_rol->close();

    // Redirección con mensaje
    $_SESSION['mensaje'] = "Empleado creado exitosamente.";
    $_SESSION['tipo_mensaje'] = "exito";
    header("Location: " . BASE_URL . "index.php");
    exit();
} else {
    echo "Método no permitido.";
}
