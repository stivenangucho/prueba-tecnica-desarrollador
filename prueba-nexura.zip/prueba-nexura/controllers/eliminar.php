<?php
session_start();
require_once(__DIR__ . '/../config/config.php');

$conexion = Conexion::conectar();

$id = $_GET['id'] ?? null;

if (!$id || !is_numeric($id)) {
    $_SESSION['mensaje'] = "ID de empleado inválido.";
    $_SESSION['tipo_mensaje'] = "error";
    header("Location: " . BASE_URL);
    exit();
}

// Eliminar relaciones en tabla empleado_rol
$stmt_rel = $conexion->prepare("DELETE FROM empleado_rol WHERE empleado_id = ?");
$stmt_rel->bind_param("i", $id);
$stmt_rel->execute();
$stmt_rel->close();

// Eliminar empleado
$stmt = $conexion->prepare("DELETE FROM empleado WHERE id = ?");
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    $_SESSION['mensaje'] = "Empleado eliminado correctamente.";
    $_SESSION['tipo_mensaje'] = "exito";
} else {
    $_SESSION['mensaje'] = "Error al eliminar empleado: " . $stmt->error;
    $_SESSION['tipo_mensaje'] = "error";
}

$stmt->close();
header("Location: " . BASE_URL);
exit();
