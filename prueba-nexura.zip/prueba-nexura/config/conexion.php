<?php

class Conexion {
    public static function conectar() {
        $host = "localhost";
        $usuario = "root";
        $contrasena = ""; 
        $base_datos = "base_datos_nexura";
        $puerto = 3306;

        $conexion = new mysqli($host, $usuario, $contrasena, $base_datos, $puerto);

        if ($conexion->connect_error) {
            die("Error de conexión: " . $conexion->connect_error);
        }

        return $conexion;
    }
}

