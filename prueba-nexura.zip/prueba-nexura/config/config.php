<?php
define('BASE_URL', 'http://localhost/prueba-nexura/');
define('CONTROLLER_PATH', BASE_URL . 'controllers/');
define('VIEW_PATH', BASE_URL . 'views/');
define('ASSETS_PATH', BASE_URL . 'assets/');

class Conexion {
    public static function conectar() {
        $host = 'localhost';
        $usuario = 'root';
        $contrasena = ''; // Cambia esto si tienes contraseña en MySQL
        $bd = 'base_datos_nexura';
        $puerto = 3306;

        $conexion = new mysqli($host, $usuario, $contrasena, $bd, $puerto);

        if ($conexion->connect_error) {
            die("Conexión fallida: " . $conexion->connect_error);
        }

        return $conexion;
    }
}
?>
