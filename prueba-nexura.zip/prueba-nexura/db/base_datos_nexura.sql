SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

-- Base de datos Prueba_nexura

CREATE DATABASE IF NOT EXISTS `base_datos_nexura` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `base_datos_nexura`;

-- Estructura para la tabla areas

DROP TABLE IF EXISTS `areas`;
CREATE TABLE IF NOT EXISTS `areas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

-- Listado de datos para la tabla areas

INSERT INTO `areas` (`id`, `nombre`) VALUES
(1, 'Administración'),
(2, 'Ventas'),
(3, 'Calidad'),
(4, 'Producción'),
(5, 'Servicios'),
(6, 'Proyectos');

-- Estructura de tabla para la tabla empleado

DROP TABLE IF EXISTS `empleado`;
CREATE TABLE IF NOT EXISTS `empleado` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `sexo` char(1) NOT NULL,
  `area_id` int(11) NOT NULL,
  `boletin` int(11) DEFAULT NULL,
  `descripcion` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `area_id` (`area_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- Datos para la tabla empleado

INSERT INTO `empleado` (`id`, `nombre`, `email`, `sexo`, `area_id`, `boletin`, `descripcion`) VALUES
(3, 'Gladis Fernández', 'gfernandez@example.com', 'F', 2, 1, 'Bienvenido'),
(4, 'Felipe Gómez', 'fgomez@example.com', 'M', 3, 0, 'Hola Felipe'),
(2, 'Adriana Loaiza', 'aloaiza@example.com', 'F', 4, 1,'Bienvenida Adriana Loaiza');

-- Estructura de tabla para la tabla empleado_rol

DROP TABLE IF EXISTS `empleado_rol`;
CREATE TABLE IF NOT EXISTS `empleado_rol` (
  `empleado_id` int(11) NOT NULL,
  `rol_id` int(11) NOT NULL,
  KEY `empleado_id` (`empleado_id`),
  KEY `rol_id` (`rol_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Volcado de datos para la tabla empleado_rol

INSERT INTO `empleado_rol` (`empleado_id`, `rol_id`) VALUES
(3, 1),
(3, 2),
(2, 3),
(2, 1),
(3, 3),
(3, 2);

-- Estructura de tabla para la tabla roles

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

-- Volcado de datos para la tabla roles

INSERT INTO `roles` (`id`, `nombre`) VALUES
(1, 'Profesional de proyectos - Desarrollador'),
(2, 'Gerente estratégico'),
(3, 'Auxiliar administrativo');

-- Restricciones para las tablas

-- Filtros para la tabla empleado
ALTER TABLE `empleado`
  ADD CONSTRAINT `empleado_ibfk_1` FOREIGN KEY (`area_id`) REFERENCES `areas` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- Filtros para la tabla empleado_rol
ALTER TABLE `empleado_rol`
  ADD CONSTRAINT `empleado_rol_ibfk_1` FOREIGN KEY (`empleado_id`) REFERENCES `empleado` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `empleado_rol_ibfk_2` FOREIGN KEY (`rol_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
